/****************************************************************************
** Meta object code from reading C++ file 'XVideoUI.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../XVideoUI.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'XVideoUI.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_XVideoUI_t {
    QByteArrayData data[13];
    char stringdata0[91];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_XVideoUI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_XVideoUI_t qt_meta_stringdata_XVideoUI = {
    {
QT_MOC_LITERAL(0, 0, 8), // "XVideoUI"
QT_MOC_LITERAL(1, 9, 4), // "Open"
QT_MOC_LITERAL(2, 14, 0), // ""
QT_MOC_LITERAL(3, 15, 4), // "Play"
QT_MOC_LITERAL(4, 20, 5), // "Pause"
QT_MOC_LITERAL(5, 26, 11), // "SliderPress"
QT_MOC_LITERAL(6, 38, 13), // "SliderRelease"
QT_MOC_LITERAL(7, 52, 6), // "SetPos"
QT_MOC_LITERAL(8, 59, 3), // "Set"
QT_MOC_LITERAL(9, 63, 6), // "Export"
QT_MOC_LITERAL(10, 70, 9), // "ExportEnd"
QT_MOC_LITERAL(11, 80, 4), // "Mark"
QT_MOC_LITERAL(12, 85, 5) // "Blend"

    },
    "XVideoUI\0Open\0\0Play\0Pause\0SliderPress\0"
    "SliderRelease\0SetPos\0Set\0Export\0"
    "ExportEnd\0Mark\0Blend"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_XVideoUI[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x0a /* Public */,
       3,    0,   70,    2, 0x0a /* Public */,
       4,    0,   71,    2, 0x0a /* Public */,
       5,    0,   72,    2, 0x0a /* Public */,
       6,    0,   73,    2, 0x0a /* Public */,
       7,    1,   74,    2, 0x0a /* Public */,
       8,    0,   77,    2, 0x0a /* Public */,
       9,    0,   78,    2, 0x0a /* Public */,
      10,    0,   79,    2, 0x0a /* Public */,
      11,    0,   80,    2, 0x0a /* Public */,
      12,    0,   81,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void XVideoUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        XVideoUI *_t = static_cast<XVideoUI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Open(); break;
        case 1: _t->Play(); break;
        case 2: _t->Pause(); break;
        case 3: _t->SliderPress(); break;
        case 4: _t->SliderRelease(); break;
        case 5: _t->SetPos((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->Set(); break;
        case 7: _t->Export(); break;
        case 8: _t->ExportEnd(); break;
        case 9: _t->Mark(); break;
        case 10: _t->Blend(); break;
        default: ;
        }
    }
}

const QMetaObject XVideoUI::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_XVideoUI.data,
      qt_meta_data_XVideoUI,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *XVideoUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *XVideoUI::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_XVideoUI.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int XVideoUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
