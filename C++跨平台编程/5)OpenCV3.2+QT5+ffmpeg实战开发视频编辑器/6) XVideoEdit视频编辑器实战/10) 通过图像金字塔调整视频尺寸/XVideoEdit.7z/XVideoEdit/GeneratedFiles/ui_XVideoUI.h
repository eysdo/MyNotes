/********************************************************************************
** Form generated from reading UI file 'XVideoUI.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_XVIDEOUI_H
#define UI_XVIDEOUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>
#include "xvideowidget.h"

QT_BEGIN_NAMESPACE

class Ui_XVideoUIClass
{
public:
    QPushButton *closeButton;
    XVideoWidget *src1;
    QPushButton *openButton;
    QSlider *playSlider;
    QLabel *label;
    QLabel *label_2;
    QSpinBox *bright;
    QDoubleSpinBox *contrast;
    QPushButton *setButton;
    XVideoWidget *des;
    QPushButton *exportButton;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QLabel *label_3;
    QComboBox *rotate;
    QLabel *label_4;
    QComboBox *flip;
    QLabel *label_5;
    QSpinBox *width;
    QSpinBox *height;
    QLabel *label_6;
    QSpinBox *pydown;
    QSpinBox *pyup;

    void setupUi(QWidget *XVideoUIClass)
    {
        if (XVideoUIClass->objectName().isEmpty())
            XVideoUIClass->setObjectName(QStringLiteral("XVideoUIClass"));
        XVideoUIClass->resize(800, 600);
        XVideoUIClass->setStyleSheet(QString::fromUtf8("#XVideoUIClass{\n"
"background-color: rgb(53, 53, 53);\n"
"}\n"
"#closeButton{\n"
"font: 75 11pt \"\347\255\211\347\272\277\";\n"
"}\n"
".QPushButton{\n"
"color: rgb(255, 255, 255);\n"
"}\n"
".QPushButton:hover{\n"
"color: rgb(0, 170, 255);\n"
"}\n"
".QLabel{\n"
"color: rgb(255, 255, 255);\n"
"}\n"
""));
        closeButton = new QPushButton(XVideoUIClass);
        closeButton->setObjectName(QStringLiteral("closeButton"));
        closeButton->setGeometry(QRect(760, 10, 28, 28));
        closeButton->setStyleSheet(QStringLiteral(""));
        closeButton->setFlat(true);
        src1 = new XVideoWidget(XVideoUIClass);
        src1->setObjectName(QStringLiteral("src1"));
        src1->setGeometry(QRect(10, 40, 380, 280));
        openButton = new QPushButton(XVideoUIClass);
        openButton->setObjectName(QStringLiteral("openButton"));
        openButton->setGeometry(QRect(420, 350, 51, 31));
        openButton->setFlat(true);
        playSlider = new QSlider(XVideoUIClass);
        playSlider->setObjectName(QStringLiteral("playSlider"));
        playSlider->setGeometry(QRect(10, 330, 380, 22));
        playSlider->setMaximum(999);
        playSlider->setOrientation(Qt::Horizontal);
        label = new QLabel(XVideoUIClass);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(420, 400, 91, 21));
        label_2 = new QLabel(XVideoUIClass);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(420, 430, 121, 21));
        bright = new QSpinBox(XVideoUIClass);
        bright->setObjectName(QStringLiteral("bright"));
        bright->setGeometry(QRect(550, 400, 101, 22));
        contrast = new QDoubleSpinBox(XVideoUIClass);
        contrast->setObjectName(QStringLiteral("contrast"));
        contrast->setGeometry(QRect(550, 430, 101, 22));
        contrast->setMinimum(1);
        contrast->setMaximum(3);
        setButton = new QPushButton(XVideoUIClass);
        setButton->setObjectName(QStringLiteral("setButton"));
        setButton->setGeometry(QRect(720, 530, 51, 31));
        setButton->setFlat(true);
        des = new XVideoWidget(XVideoUIClass);
        des->setObjectName(QStringLiteral("des"));
        des->setGeometry(QRect(400, 40, 380, 280));
        exportButton = new QPushButton(XVideoUIClass);
        exportButton->setObjectName(QStringLiteral("exportButton"));
        exportButton->setGeometry(QRect(610, 330, 181, 51));
        exportButton->setFlat(true);
        playButton = new QPushButton(XVideoUIClass);
        playButton->setObjectName(QStringLiteral("playButton"));
        playButton->setGeometry(QRect(120, 390, 51, 51));
        pauseButton = new QPushButton(XVideoUIClass);
        pauseButton->setObjectName(QStringLiteral("pauseButton"));
        pauseButton->setGeometry(QRect(190, 390, 51, 51));
        label_3 = new QLabel(XVideoUIClass);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(420, 460, 61, 21));
        rotate = new QComboBox(XVideoUIClass);
        rotate->setObjectName(QStringLiteral("rotate"));
        rotate->setGeometry(QRect(550, 460, 101, 22));
        label_4 = new QLabel(XVideoUIClass);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(420, 490, 61, 21));
        flip = new QComboBox(XVideoUIClass);
        flip->setObjectName(QStringLiteral("flip"));
        flip->setGeometry(QRect(550, 490, 101, 22));
        label_5 = new QLabel(XVideoUIClass);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(420, 520, 91, 21));
        width = new QSpinBox(XVideoUIClass);
        width->setObjectName(QStringLiteral("width"));
        width->setGeometry(QRect(520, 520, 61, 22));
        width->setMaximum(99999);
        height = new QSpinBox(XVideoUIClass);
        height->setObjectName(QStringLiteral("height"));
        height->setGeometry(QRect(590, 520, 61, 22));
        height->setMaximum(99999);
        label_6 = new QLabel(XVideoUIClass);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(310, 550, 201, 21));
        pydown = new QSpinBox(XVideoUIClass);
        pydown->setObjectName(QStringLiteral("pydown"));
        pydown->setGeometry(QRect(520, 550, 61, 22));
        pydown->setMaximum(100);
        pyup = new QSpinBox(XVideoUIClass);
        pyup->setObjectName(QStringLiteral("pyup"));
        pyup->setGeometry(QRect(590, 550, 61, 22));
        pyup->setMaximum(100);

        retranslateUi(XVideoUIClass);
        QObject::connect(closeButton, SIGNAL(clicked()), XVideoUIClass, SLOT(close()));
        QObject::connect(openButton, SIGNAL(clicked()), XVideoUIClass, SLOT(Open()));
        QObject::connect(playSlider, SIGNAL(sliderPressed()), XVideoUIClass, SLOT(SliderPress()));
        QObject::connect(playSlider, SIGNAL(sliderReleased()), XVideoUIClass, SLOT(SliderRelease()));
        QObject::connect(playSlider, SIGNAL(sliderMoved(int)), XVideoUIClass, SLOT(SetPos(int)));
        QObject::connect(setButton, SIGNAL(clicked()), XVideoUIClass, SLOT(Set()));
        QObject::connect(exportButton, SIGNAL(clicked()), XVideoUIClass, SLOT(Export()));
        QObject::connect(playButton, SIGNAL(clicked()), XVideoUIClass, SLOT(Play()));
        QObject::connect(pauseButton, SIGNAL(clicked()), XVideoUIClass, SLOT(Pause()));

        QMetaObject::connectSlotsByName(XVideoUIClass);
    } // setupUi

    void retranslateUi(QWidget *XVideoUIClass)
    {
        XVideoUIClass->setWindowTitle(QApplication::translate("XVideoUIClass", "XVideoUI", Q_NULLPTR));
        closeButton->setText(QApplication::translate("XVideoUIClass", "X", Q_NULLPTR));
        openButton->setText(QApplication::translate("XVideoUIClass", "\346\211\223\345\274\200", Q_NULLPTR));
        label->setText(QApplication::translate("XVideoUIClass", "\344\272\256\345\272\246[0-100]", Q_NULLPTR));
        label_2->setText(QApplication::translate("XVideoUIClass", "\345\257\271\346\257\224\345\272\246[1.0-3.0]", Q_NULLPTR));
        setButton->setText(QApplication::translate("XVideoUIClass", "\350\256\276\347\275\256", Q_NULLPTR));
        exportButton->setText(QApplication::translate("XVideoUIClass", "\345\257\274\345\207\272", Q_NULLPTR));
        playButton->setText(QApplication::translate("XVideoUIClass", "play", Q_NULLPTR));
        pauseButton->setText(QApplication::translate("XVideoUIClass", "pause", Q_NULLPTR));
        label_3->setText(QApplication::translate("XVideoUIClass", "\345\233\276\345\203\217\346\227\213\350\275\254", Q_NULLPTR));
        rotate->clear();
        rotate->insertItems(0, QStringList()
         << QApplication::translate("XVideoUIClass", "0", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "90", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "180", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "270", Q_NULLPTR)
        );
        label_4->setText(QApplication::translate("XVideoUIClass", "\345\233\276\345\203\217\351\225\234\345\203\217", Q_NULLPTR));
        flip->clear();
        flip->insertItems(0, QStringList()
         << QApplication::translate("XVideoUIClass", "\344\270\215\345\244\204\347\220\206", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "\344\270\212\344\270\213\351\225\234\345\203\217", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "\345\267\246\345\217\263\351\225\234\345\203\217", Q_NULLPTR)
         << QApplication::translate("XVideoUIClass", "\344\270\212\344\270\213\345\267\246\345\217\263\351\225\234\345\203\217", Q_NULLPTR)
        );
        label_5->setText(QApplication::translate("XVideoUIClass", "\345\233\276\345\203\217\345\260\272\345\257\270W,H", Q_NULLPTR));
        label_6->setText(QApplication::translate("XVideoUIClass", "\345\233\276\345\203\217\351\207\221\345\255\227\345\241\224(\351\253\230\346\226\257\343\200\201\346\213\211\346\231\256\346\213\211\346\226\257)", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class XVideoUIClass: public Ui_XVideoUIClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_XVIDEOUI_H
