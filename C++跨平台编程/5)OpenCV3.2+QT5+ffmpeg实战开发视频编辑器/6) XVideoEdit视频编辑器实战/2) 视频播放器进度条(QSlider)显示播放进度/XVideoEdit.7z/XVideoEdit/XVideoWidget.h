#pragma once
#include <QOpenGLWidget>
#include <opencv2/core.hpp>
class XVideoWidget :public QOpenGLWidget
{
	Q_OBJECT

public:
	XVideoWidget(QWidget *parent);
	void paintEvent(QPaintEvent *e);
	virtual ~XVideoWidget();

public slots:
	void SetImage(cv::Mat mat);
protected:
	QImage img;
};

