#include "test_qt_mat.h"

test_qt_mat::test_qt_mat(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}
