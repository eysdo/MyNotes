/********************************************************************************
** Form generated from reading UI file 'test_qt_mat.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEST_QT_MAT_H
#define UI_TEST_QT_MAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>
#include "matview.h"

QT_BEGIN_NAMESPACE

class Ui_test_qt_matClass
{
public:
    MatView *mat;

    void setupUi(QWidget *test_qt_matClass)
    {
        if (test_qt_matClass->objectName().isEmpty())
            test_qt_matClass->setObjectName(QStringLiteral("test_qt_matClass"));
        test_qt_matClass->resize(684, 591);
        mat = new MatView(test_qt_matClass);
        mat->setObjectName(QStringLiteral("mat"));
        mat->setGeometry(QRect(19, 19, 512, 512));

        retranslateUi(test_qt_matClass);

        QMetaObject::connectSlotsByName(test_qt_matClass);
    } // setupUi

    void retranslateUi(QWidget *test_qt_matClass)
    {
        test_qt_matClass->setWindowTitle(QApplication::translate("test_qt_matClass", "test_qt_mat", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class test_qt_matClass: public Ui_test_qt_matClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEST_QT_MAT_H
