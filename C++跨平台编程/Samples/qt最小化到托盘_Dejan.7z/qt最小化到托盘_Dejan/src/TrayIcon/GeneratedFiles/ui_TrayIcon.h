/********************************************************************************
** Form generated from reading UI file 'TrayIcon.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAYICON_H
#define UI_TRAYICON_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TrayIconClass
{
public:

    void setupUi(QWidget *TrayIconClass)
    {
        if (TrayIconClass->objectName().isEmpty())
            TrayIconClass->setObjectName(QStringLiteral("TrayIconClass"));
        TrayIconClass->resize(600, 400);

        retranslateUi(TrayIconClass);

        QMetaObject::connectSlotsByName(TrayIconClass);
    } // setupUi

    void retranslateUi(QWidget *TrayIconClass)
    {
        TrayIconClass->setWindowTitle(QApplication::translate("TrayIconClass", "TrayIcon", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TrayIconClass: public Ui_TrayIconClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAYICON_H
