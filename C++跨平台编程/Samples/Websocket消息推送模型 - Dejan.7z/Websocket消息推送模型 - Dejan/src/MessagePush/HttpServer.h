#pragma once

#include <QtCore/QObject>
#include <evpp/http/http_server.h>

class HttpServer : public QObject
{
	Q_OBJECT

private:
	evpp::http::Server* mHttpServer = nullptr;

public:

	explicit HttpServer(quint16 port, int thread_num = 2, QObject *parent = nullptr);
	virtual ~HttpServer();

Q_SIGNALS:
	// HTTP API ���÷�����Ϣ
	void sendMsg(int sid, QString data);
};

