/********************************************************************************
** Form generated from reading UI file 'MessagePush.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESSAGEPUSH_H
#define UI_MESSAGEPUSH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MessagePushClass
{
public:
    QGroupBox *groupBox_serverStatus;
    QLabel *label_onLine;
    QLabel *label_onLineCount;
    QGroupBox *groupBox_actMsg;
    QTextEdit *textEdit_log;

    void setupUi(QWidget *MessagePushClass)
    {
        if (MessagePushClass->objectName().isEmpty())
            MessagePushClass->setObjectName(QStringLiteral("MessagePushClass"));
        MessagePushClass->resize(471, 421);
        QFont font;
        font.setPointSize(15);
        MessagePushClass->setFont(font);
        groupBox_serverStatus = new QGroupBox(MessagePushClass);
        groupBox_serverStatus->setObjectName(QStringLiteral("groupBox_serverStatus"));
        groupBox_serverStatus->setGeometry(QRect(10, 10, 451, 61));
        QFont font1;
        font1.setPointSize(8);
        groupBox_serverStatus->setFont(font1);
        label_onLine = new QLabel(groupBox_serverStatus);
        label_onLine->setObjectName(QStringLiteral("label_onLine"));
        label_onLine->setGeometry(QRect(10, 20, 111, 21));
        QFont font2;
        font2.setPointSize(12);
        label_onLine->setFont(font2);
        label_onLineCount = new QLabel(groupBox_serverStatus);
        label_onLineCount->setObjectName(QStringLiteral("label_onLineCount"));
        label_onLineCount->setGeometry(QRect(120, 20, 111, 21));
        label_onLineCount->setFont(font2);
        groupBox_actMsg = new QGroupBox(MessagePushClass);
        groupBox_actMsg->setObjectName(QStringLiteral("groupBox_actMsg"));
        groupBox_actMsg->setGeometry(QRect(10, 80, 451, 331));
        groupBox_actMsg->setFont(font1);
        textEdit_log = new QTextEdit(groupBox_actMsg);
        textEdit_log->setObjectName(QStringLiteral("textEdit_log"));
        textEdit_log->setGeometry(QRect(10, 20, 431, 301));

        retranslateUi(MessagePushClass);

        QMetaObject::connectSlotsByName(MessagePushClass);
    } // setupUi

    void retranslateUi(QWidget *MessagePushClass)
    {
        MessagePushClass->setWindowTitle(QApplication::translate("MessagePushClass", "MessagePush", Q_NULLPTR));
        groupBox_serverStatus->setTitle(QApplication::translate("MessagePushClass", "\346\234\215\345\212\241\345\231\250\347\212\266\346\200\201", Q_NULLPTR));
        label_onLine->setText(QApplication::translate("MessagePushClass", "\345\275\223\345\211\215\345\234\250\347\272\277\344\272\272\346\225\260:", Q_NULLPTR));
        label_onLineCount->setText(QApplication::translate("MessagePushClass", "0", Q_NULLPTR));
        groupBox_actMsg->setTitle(QApplication::translate("MessagePushClass", "\346\223\215\344\275\234\344\277\241\346\201\257", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MessagePushClass: public Ui_MessagePushClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESSAGEPUSH_H
