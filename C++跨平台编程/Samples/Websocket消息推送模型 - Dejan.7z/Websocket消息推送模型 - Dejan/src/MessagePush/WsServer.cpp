#include "WsServer.h"
#include "QtWebSockets/qwebsocketserver.h"
#include "QtWebSockets/qwebsocket.h"
// ---------------- ���� ---------------
#include <iostream>
using namespace std;
// ---------------- ���� ---------------

QT_USE_NAMESPACE

/* �вι��캯�� */
WsServer::WsServer(quint16 port, QObject *parent) 
	: QObject(parent),
	mWsServer(new QWebSocketServer(QStringLiteral("WsServer"),
		QWebSocketServer::NonSecureMode, this))
{
	if (mWsServer->listen(QHostAddress::Any, port)) {
		qDebug() << "WsServer listening on port" << port;

		//connect(sender, signal, receiver, slot);
		connect(mWsServer, &QWebSocketServer::newConnection, this, &WsServer::onNewConnection);
		connect(mWsServer, &QWebSocketServer::closed, this, &WsServer::closed);
	}
}

/* ws�����ӻص� */
void WsServer::onNewConnection()
{
	QWebSocket *pSocket = mWsServer->nextPendingConnection();
	mClients.insert(pSocket);

	connect(pSocket, &QWebSocket::textMessageReceived, this, &WsServer::processTextMessage);
	connect(pSocket, &QWebSocket::disconnected, this, &WsServer::socketDisconnected);

	//  ���µ�ǰ��������ͳ����ʾ
	updateOnLineCount(mClients.size());
	
	showLog(qMove(QString::fromLocal8Bit("[���û�����]:") + QString::number((int)pSocket)));
	cout << pSocket << endl;
}

/* ws������Ϣ�ص� */
void WsServer::processTextMessage(QString msg)
{
	QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
	showLog(qMove("Message received:" + msg));
	
	//if (pClient) pClient->sendTextMessage(msg);
}

/* ws���ӶϿ��ص� */
void WsServer::socketDisconnected()
{
	QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
	showLog(qMove(QString::fromLocal8Bit("[�û��˳�]:") + QString::number((int)pClient)));
	if (pClient) {
		mClients.erase(pClient);
		pClient->deleteLater();
	}
	// ���µ�ǰ��������ͳ����ʾ
	updateOnLineCount(mClients.size());
}

/* �������� */
WsServer::~WsServer()
{
	mWsServer->close();
	mClients.clear();
}

// HTTP API ���÷�����Ϣ
void WsServer::sendMsg(int sid, QString data)
{
	QWebSocket* sock = (QWebSocket*)sid;
	sock->sendTextMessage(data);
}