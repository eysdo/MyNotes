#include "MessagePush.h"
#include <QtWidgets/QApplication>
#include "WsServer.h"
#include "HttpServer.h"

#pragma comment(lib, "Shell32.lib")

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	MessagePush w;
	w.show();

	// ---------  Http Server ---------
	int http_port = 9092;
	int http_thread_num = 4;
	HttpServer* http_server = new HttpServer(http_port, http_thread_num);


	// ---------  Websocket Server ---------
	int ws_port = 9096;
	WsServer* ws_server = new WsServer(ws_port);
	QObject::connect(ws_server, &WsServer::closed, &a, &QCoreApplication::quit);
	// ������Ϣ����źŲ۹���
	QObject::connect(ws_server, &WsServer::showLog, &w, &MessagePush::showLog);
	// ���µ�ǰ��������ͳ����ʾ�źŲ۹���
	QObject::connect(ws_server, &WsServer::updateOnLineCount, &w, &MessagePush::updateOnLineCount);


	// Http Server API -> Websocket Server sendMsg() �źŲ۹���
	QObject::connect(http_server, &HttpServer::sendMsg, ws_server, &WsServer::sendMsg);


	return a.exec();
}
