#include "HttpServer.h"
#include <evpp/libevent.h>
#include <evpp/httpc/request.h>
#include <evpp/httpc/response.h>
#include "winmain-inl.h"
#include <string>
#include <iostream>
/// JSON����� RapidJSON
//=========================
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
using namespace rapidjson;

using namespace std;

#pragma comment(lib, "Advapi32.lib")


/* �вι��캯�� */
HttpServer::HttpServer(quint16 port, int thread_num, QObject *parent)
	:QObject(parent),
	mHttpServer(new evpp::http::Server(thread_num))
{
	mHttpServer->SetThreadDispatchPolicy(evpp::ThreadDispatchPolicy::kIPAddressHashing);
	mHttpServer->RegisterDefaultHandler([this](evpp::EventLoop* loop,
		const evpp::http::ContextPtr& ctx,
		const evpp::http::HTTPSendResponseCallback& cb) 
	{
		int http_code = 200;
		std::string reply_data = "{\"code\":200, \"msg\":\"success!\"}";
		//const char* content_type = (char*)ctx->FindRequestHeader("Content-Type");

		if (ctx->req()->type != EVHTTP_REQ_POST)
		{
			http_code = 403;
			reply_data = "{\"code\":403, \"msg\":\"Forbidden!\"}";
			ctx->set_response_http_code(http_code);
			cb(reply_data);
			return;
		}

		// �ɹ��ص�
		ctx->AddResponseHeader("Content-Type", "application/json");

		// JSON��ʽ�ж�
		string req_data(move(ctx->body().ToString()));
		Document paramData;
		if (paramData.Parse(req_data.c_str()).HasParseError())
		{
			http_code = 403;
			reply_data = "{\"code\":403, \"msg\":\"JSON format exception!\"}";
			ctx->set_response_http_code(http_code);
			cb(reply_data);
			return;
		}

		// ָ��sid����
		int sid = paramData["sid"].IsNull() || !paramData["sid"].IsNumber() ? 0 : paramData["sid"].GetInt();
		QString msgData = paramData["data"].IsNull() || !paramData["data"].IsString() ? "" : move(paramData["data"].GetString());

		sendMsg(sid, msgData);

		ctx->set_response_http_code(http_code);
		cb(reply_data);
	});
	mHttpServer->Init(port);
	mHttpServer->Start();
}


HttpServer::~HttpServer()
{
}


