#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include "FTPClient.h"
using namespace std;

#define PRINT_LOG [](const std::string& strLogMsg) { std::cout << strLogMsg << std::endl;  }

int main(int argc, char **argv)
{
	unique_ptr<CFTPClient> FTPClient(new CFTPClient(PRINT_LOG));
	bool ret = FTPClient->InitSession("192.168.3.130",
		21,
		"mt_safe",
		"123456"
	);
	if (ret) cout << "ftp�ͻ������ӳɹ�!" << endl;

	FTPClient->SetTimeout(10);
	//FTPClient->SetActive(true);
	//FTPClient->SetNoSignal(true);
	
	// ��ӡ�ļ��б�
	/*string strList;
	FTPClient->List("/", strList, true);
	cout << strList << endl;*/

	// �ο��ĵ�: https://github.com/embeddedmz/ftpclient-cpp
	// �ϴ��ļ�
	ret = FTPClient->UploadFile("C:\\application.evtx","/123/test.evtx",true);
	if (ret) cout << "�ϴ��ļ��ɹ�!" << endl;

	

	getchar();
	return 0;
}