/********************************************************************************
** Form generated from reading UI file 'testwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTWIDGET_H
#define UI_TESTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TestWidgetClass
{
public:

    void setupUi(QWidget *TestWidgetClass)
    {
        if (TestWidgetClass->objectName().isEmpty())
            TestWidgetClass->setObjectName(QStringLiteral("TestWidgetClass"));
        TestWidgetClass->resize(600, 400);

        retranslateUi(TestWidgetClass);

        QMetaObject::connectSlotsByName(TestWidgetClass);
    } // setupUi

    void retranslateUi(QWidget *TestWidgetClass)
    {
        TestWidgetClass->setWindowTitle(QApplication::translate("TestWidgetClass", "TestWidget", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TestWidgetClass: public Ui_TestWidgetClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTWIDGET_H
