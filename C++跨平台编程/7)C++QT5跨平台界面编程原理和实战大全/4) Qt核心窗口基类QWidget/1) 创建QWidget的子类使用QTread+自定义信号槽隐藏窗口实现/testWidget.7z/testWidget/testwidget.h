#pragma once

#include <QtWidgets/QWidget>
#include "ui_testwidget.h"

class TestWidget : public QWidget
{
	Q_OBJECT

public:
	TestWidget(QWidget *parent = Q_NULLPTR);

private:
	Ui::TestWidgetClass ui;
};
