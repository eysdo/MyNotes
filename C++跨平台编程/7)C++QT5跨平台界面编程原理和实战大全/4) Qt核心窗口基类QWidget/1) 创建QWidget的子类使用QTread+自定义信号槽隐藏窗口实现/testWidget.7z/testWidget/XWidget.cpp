#include "XWidget.h"



XWidget::XWidget()
{
	// �ֶ����źŲ�
	connect(this, SIGNAL(Hide()), this, SLOT(hide()));
}


XWidget::~XWidget()
{
}
