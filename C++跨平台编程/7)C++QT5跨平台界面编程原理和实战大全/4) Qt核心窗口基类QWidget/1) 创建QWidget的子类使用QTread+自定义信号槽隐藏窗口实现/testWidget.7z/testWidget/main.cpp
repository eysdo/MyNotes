//#include "testwidget.h"
#include <QtWidgets/QApplication>
#include "XWidget.h"
#include <QThread>

static XWidget *w = NULL;

class XThread :public QThread 
{
public:
	void run() 
	{
		QThread::msleep(3000);
		w->Hide(); // Hide()���ź�, ������
		//w->hide(); // �϶���崵�! ��Ϊ hide()�ǲۺ���
	}
};
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	w = new XWidget();
	XThread xt;
	w->show();
	xt.start();
	/*QWidget w;
	w.setWindowTitle("my window!");
	w.show();*/
	//w.hide();

	//TestWidget w;
	//w.show();
	return a.exec();
}
