#include "testwidget.h"

TestWidget::TestWidget(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}
