#include "testsignal.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	TestSignal w;
	w.show();
	return a.exec();
}
