#pragma once

#include <QtWidgets/QWidget>
#include "ui_testsignal.h"

class TestSignal : public QWidget
{
	Q_OBJECT

public:
	TestSignal(QWidget *parent = Q_NULLPTR);

signals:
	void ViewSig();

public slots:
	void ViewSlot();
	void TestSlot();

private:
	Ui::TestSignalClass ui;
};
