#include "testsignal.h"
#include <iostream>
using namespace std;

TestSignal::TestSignal(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	ViewSig();
	QObject::connect(ui.testSlotButton, SIGNAL(clicked()), this, SLOT(TestSlot()));
}

void TestSignal::TestSlot()
{
	cout << "TestSlot" << endl;
}

void TestSignal::ViewSlot()
{
	cout << "ViewSlot" << endl;
}