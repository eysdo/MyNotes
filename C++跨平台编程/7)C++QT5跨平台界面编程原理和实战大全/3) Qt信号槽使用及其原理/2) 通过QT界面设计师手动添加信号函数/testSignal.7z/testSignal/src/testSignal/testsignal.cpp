#include "testsignal.h"
#include <iostream>
using namespace std;

TestSignal::TestSignal(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	ViewSig();
}

void TestSignal::ViewSlot()
{
	cout << "ViewSlot" << endl;
}