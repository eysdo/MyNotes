/********************************************************************************
** Form generated from reading UI file 'testsignal.ui'
**
** Created by: Qt User Interface Compiler version 5.9.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TESTSIGNAL_H
#define UI_TESTSIGNAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TestSignalClass
{
public:
    QPushButton *closeButton;
    QPushButton *minButton;
    QPushButton *viewSlotButton;

    void setupUi(QWidget *TestSignalClass)
    {
        if (TestSignalClass->objectName().isEmpty())
            TestSignalClass->setObjectName(QStringLiteral("TestSignalClass"));
        TestSignalClass->resize(600, 400);
        closeButton = new QPushButton(TestSignalClass);
        closeButton->setObjectName(QStringLiteral("closeButton"));
        closeButton->setGeometry(QRect(140, 80, 93, 28));
        minButton = new QPushButton(TestSignalClass);
        minButton->setObjectName(QStringLiteral("minButton"));
        minButton->setGeometry(QRect(280, 80, 93, 28));
        viewSlotButton = new QPushButton(TestSignalClass);
        viewSlotButton->setObjectName(QStringLiteral("viewSlotButton"));
        viewSlotButton->setGeometry(QRect(140, 170, 111, 28));

        retranslateUi(TestSignalClass);
        QObject::connect(closeButton, SIGNAL(clicked()), TestSignalClass, SLOT(close()));
        QObject::connect(minButton, SIGNAL(clicked()), TestSignalClass, SLOT(showMinimized()));
        QObject::connect(viewSlotButton, SIGNAL(clicked()), TestSignalClass, SLOT(ViewSlot()));
        QObject::connect(TestSignalClass, SIGNAL(ViewSig()), TestSignalClass, SLOT(ViewSlot()));

        QMetaObject::connectSlotsByName(TestSignalClass);
    } // setupUi

    void retranslateUi(QWidget *TestSignalClass)
    {
        TestSignalClass->setWindowTitle(QApplication::translate("TestSignalClass", "TestSignal", Q_NULLPTR));
        closeButton->setText(QApplication::translate("TestSignalClass", "\345\205\263\351\227\255\347\252\227\345\217\243", Q_NULLPTR));
        minButton->setText(QApplication::translate("TestSignalClass", "\346\234\200\345\260\217\345\214\226", Q_NULLPTR));
        viewSlotButton->setText(QApplication::translate("TestSignalClass", "ViewSlot", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class TestSignalClass: public Ui_TestSignalClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TESTSIGNAL_H
