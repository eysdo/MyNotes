#pragma once
#include <list>
#include <mutex>
#include <QThread>
struct AVPacket;
class XDecode;

class XDecodeThread : public QThread
{
public:
	virtual void Push(AVPacket *pkt);

	// ȡ��һ֡����, ����ջ, ���û�з���NULL
	virtual AVPacket *Pop();

	XDecodeThread();
	virtual ~XDecodeThread();

public:
	int _maxList = 100; // ������
	bool _isExit = false;

protected:
	std::list<AVPacket *> _packs;
	std::mutex _mux;
	XDecode *_decode = 0;
};

