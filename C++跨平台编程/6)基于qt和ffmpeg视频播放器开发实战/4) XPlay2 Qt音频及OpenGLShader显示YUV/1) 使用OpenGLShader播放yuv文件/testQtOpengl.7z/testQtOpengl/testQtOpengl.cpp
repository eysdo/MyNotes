#include "testQtOpengl.h"

testQtOpengl::testQtOpengl(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}
