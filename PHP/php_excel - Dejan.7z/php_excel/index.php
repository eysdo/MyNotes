<?php
include_once './lib/PHPExcel/PHPExcel.php';

class Xls
{
    /**
     * exportExcel 导出els  - Author:Dejan   2017-8-9
     * @param  $expTitle     导出文件名称
     * @param  $expCellName  表头排序对应名称
     * @param  $expTableData 导出数据[二维数组]
     */
    static function exportExcel($expTitle,$expCellName,$expTableData){
        //$xlsTitle = iconv('utf-8', 'gb2312', $expTitle);//文件名称
        $xlsTitle = $expTitle;//文件名称
        $fileName = $expTitle.date('_YmdHis');//or $xlsTitle 文件名称可根据自己情况设定
        $cellNum = count($expCellName);
        $dataNum = count($expTableData);
    
        //vendor("PHPExcel.PHPExcel");
    
        $objPHPExcel = new \PHPExcel();
        $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
    
        $objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');//合并单元格
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'  Export time:'.date('Y-m-d H:i:s'));
        for($i=0;$i<$cellNum;$i++){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'2', $expCellName[$i][1]);
        }
        // Miscellaneous glyphs, UTF-8
        for($i=0;$i<$dataNum;$i++){
            for($j=0;$j<$cellNum;$j++){
                $objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+3), $expTableData[$i][$expCellName[$j][0]]);
            }
        }
    
        header('pragma:public');
        $fileName=iconv('utf-8','GBK//IGNORE',urlencode($fileName));
        header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
        header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save('php://output');
        exit;
    }
    
    /**
     * importExcel  - Author:Dejan   2017-8-14
     * @param  $filename  文件路径
     */
    static function importExcel($filename){
        /*
                 --- 导入学生格式 ---
                    姓名           性别              生日               入学年份
                    Dejan           男            1996-05-30              2016
        */
        if(is_file($filename)){
            $file_name=$filename;
            $objReader = \PHPExcel_IOFactory::createReader('Excel5'); // 读取 *.xls文件
            $objPHPExcel = $objReader->load($file_name,$encode='utf-8'); // 加载编码使用UTF-8
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow(); // 取得总行数(注意:这个不一定准确, 所以不能用做数组下标)
            $highestColumn = $sheet->getHighestColumn(); // 取得总列数(注意:这个不一定准确, 所以不能用做数组下标)
            
            $rowIsNull = 0; # 空行统计, 前面"总行数"为什么会不准确就因为他了~
            for($i=3;$i<=$highestRow;$i++){ // 从第三行开始分析导入数据
                $data['name'] = $objPHPExcel->getActiveSheet()->getCell("A".$i)->getValue();     # Dejan  -姓名
                $data['sex'] = $objPHPExcel->getActiveSheet()->getCell("B".$i)->getValue();      # 男  -性别
                $data['birthday'] = $objPHPExcel->getActiveSheet()->getCell("C".$i)->getValue(); # 1996-05-30 -生日
                $data['year'] = $objPHPExcel->getActiveSheet()->getCell("D".$i)->getValue();     # 2016 入学年份
                
                # 空行检测跳过
                if($data['name']==''&&$data['sex']==''&&$data['birthday']==''&&$data['year']==''){
                    $rowIsNull++; // 空行计数 +1
                    continue;
                }
                
                $data_list[]=$data; # 用户信息放到新容器
            }
            
			echo '用户总数:'.($highestRow-2-$rowIsNull)."<br/>";
            # 数据输出
            foreach($data_list as $v){
                echo "姓名:".$v['name']." 性别:".$v['sex']." 生日:".$v['birthday']." year:".$v['year']."<br/>";
            }

        }else{
            echo 'xls文件不存在!';
        }
    }
    
}

/* 导出 XLS - Sample Start */
/*
$data = [
    ['userno'=>1, 'name'=>'Dejan', 'sex'=>'男', 'birthday'=>'1996-05-30', 'loginno'=>'9696'],
    ['userno'=>2, 'name'=>'Dejan2', 'sex'=>'男', 'birthday'=>'1996-05-30', 'loginno'=>'9696'],
    ['userno'=>3, 'name'=>'Dejan3', 'sex'=>'男', 'birthday'=>'1996-05-30', 'loginno'=>'9696']
];
$xlsName  = '班级数据导出';
$xlsCell  = array(
    array('userno','学号'),
    array('name','姓名'),
    array('sex','性别'),
    array('birthday','生日'),
    array('loginno','账号')
);
Xls::exportExcel($xlsName,$xlsCell,$data);
exit;
*/
/* 导出 XLS - Sample End */


/* 导入 XLS - Sample */
Xls::importExcel('./test.xls');
